/*
  Author: Aytac GUL
  Web: http://www.aytacgul.com
  
  Single demo file that shows all main functions of the library.
  
  String Chars List: "A,B,C,D,E,F,H,I,J,L,N,O,P,R,S,T,U,Y"
  Numbers: "0,1,2,3,4,5,6,7,8,9" 7 segment
  Special Char : "-_º" 
  

  Wiring:
    Module DIN -> Arduino data pin (D5)
    Module CLK -> Arduino clock pin (D4)
    Module VCC -> 5V
    Module GND -> GND

  Display numbering used in this demo:
      [DISPLAY1] [DISPLAY2]
      [DISPLAY3] [DISPLAY4]
*/

#include <TM1640_4x4CC.h>

// Change pins as needed for Nano / ESP32 / ESP8266.
TM1640_4x4CC display(5, 4);   // DIN, CLK

void setup() {
  display.begin();

  // 1) Brightness and on/off control.
  display.setBrightness(7);   // 0..7max
  display.setOn(true);

  // 2) Clear everything.
  display.clear();

  // 3) Write plain text to the 4 physical displays.
  // Dot syntax: a '.' lights the previous digit dot.
  display.setDisplay1("12.34");
  display.setDisplay2("HELP");
  display.setDisplay3("-123");
  display.setDisplay4("26xC");
  display.update();
  delay(2000);

  // 4) Clear only one display.
  display.clearDisplay(1);    // clear DISPLAY2 only
  display.update();
  delay(1000);

  // 5) Write an integer value.
  int sensorValue = 708;
  display.setDisplayNumber(1, sensorValue, false);  // DISPLAY2 =  708

  // 6) Show clock format HH:MM.
  // On this PCB, the dot of digit 2 is shared with the ':' LEDs.
  display.setDisplayClock(2, 17, 8, true);          // DISPLAY3 = 17:08

  // 7) Write each digit manually.
  // Example result on DISPLAY4: [1][7.][0][8.]
  display.setDigit(3, 0, '2', false);
  display.setDigit(3, 1, '7', false);
  display.setDigit(3, 2, 'x', false);
  display.setDigit(3, 3, 'C', false);

  // 8) Raw segment example on DISPLAY1 digit 0.
  // 0x40 = segment G only -> '-'
  display.setDigitRaw(4, 0x40); // raw global digit index, use only if needed

  display.update();
}

void loop() {
  // Blink the shared colon on DISPLAY3.
  display.setDisplayClock(2, 17, 8, true);
  display.update();
  delay(500);

  display.setDisplayClock(2, 17, 8, false);
  display.update();
  delay(500);
}
