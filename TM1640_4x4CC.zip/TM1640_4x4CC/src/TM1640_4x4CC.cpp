#include "TM1640_4x4CC.h"

TM1640_4x4CC::TM1640_4x4CC(uint8_t dataPin, uint8_t clockPin)
    : _dataPin(dataPin), _clockPin(clockPin), _brightness(7), _displayOn(true) {
    clear();
}

void TM1640_4x4CC::begin() {
    pinMode(_dataPin, OUTPUT);
    pinMode(_clockPin, OUTPUT);
    digitalWrite(_dataPin, HIGH);
    digitalWrite(_clockPin, HIGH);
    clear();
    update();
}

void TM1640_4x4CC::clear() {
    for (uint8_t i = 0; i < 16; i++) {
        _buffer[i] = 0x00;
    }
}

void TM1640_4x4CC::clearDisplay(uint8_t displayIndex) {
    if (displayIndex > 3) return;
    for (uint8_t digit = 0; digit < 4; digit++) {
        _buffer[rawIndex(displayIndex, digit)] = 0x00;
    }
}

void TM1640_4x4CC::setBrightness(uint8_t brightness) {
    _brightness = brightness & 0x07;
}

void TM1640_4x4CC::setOn(bool state) {
    _displayOn = state;
}

uint8_t TM1640_4x4CC::mapDisplay(uint8_t displayIndex) const {
    static const uint8_t kMap[4] = {1, 0, 3, 2};
    return (displayIndex < 4) ? kMap[displayIndex] : 0;
}

uint8_t TM1640_4x4CC::rawIndex(uint8_t displayIndex, uint8_t digitIndex) const {
    return (mapDisplay(displayIndex) * 4) + digitIndex;
}

uint8_t TM1640_4x4CC::encodeChar(char c) const {
    switch (c) {
        case '0': return 0b00111111;
        case '1': return 0b00000110;
        case '2': return 0b01011011;
        case '3': return 0b01001111;
        case '4': return 0b01100110;
        case '5': return 0b01101101;
        case '6': return 0b01111101;
        case '7': return 0b00000111;
        case '8': return 0b01111111;
        case '9': return 0b01101111;

        case 'A': case 'a': return 0b01110111;
        case 'B': case 'b': return 0b01111100;
        case 'C': case 'c': return 0b00111001;
        case 'D': case 'd': return 0b01011110;
        case 'E': case 'e': return 0b01111001;
        case 'F': case 'f': return 0b01110001;
        case 'H': case 'h': return 0b01110110;
        case 'I': case 'i': return 0b00000110;
        case 'J': case 'j': return 0b00011110;
        case 'L': case 'l': return 0b00111000;
        case 'N': case 'n': return 0b01010100;
        case 'O': case 'o': return 0b01011100;
        case 'P': case 'p': return 0b01110011;
        case 'R': case 'r': return 0b01010000;
        case 'S': case 's': return 0b01101101;
        case 'T': case 't': return 0b01111000;
        case 'U': case 'u': return 0b00111110;
        case 'Y': case 'y': return 0b01101110;
		
		case 'X': case 'x': return 0b01100011;
		
        case '-': return 0b01000000;
        case '_': return 0b00001000;
        case ' ': return 0b00000000;
        default:  return 0b00000000;
    }
}

void TM1640_4x4CC::setDigitRaw(uint8_t globalDigitIndex, uint8_t segments) {
    if (globalDigitIndex > 15) return;
    _buffer[globalDigitIndex] = segments;
}

void TM1640_4x4CC::setDigit(uint8_t displayIndex, uint8_t digitIndex, char value, bool dot) {
    if (displayIndex > 3 || digitIndex > 3) return;

    uint8_t seg = encodeChar(value);
    if (dot) seg |= 0x80;
    _buffer[rawIndex(displayIndex, digitIndex)] = seg;
}

void TM1640_4x4CC::setDisplay(uint8_t displayIndex, const char* text) {
    if (displayIndex > 3 || text == nullptr) return;

    clearDisplay(displayIndex);

    uint8_t digit = 0;
    for (uint16_t i = 0; text[i] != '\0' && digit < 4; i++) {
        if (text[i] == '.') {
            if (digit > 0) {
                _buffer[rawIndex(displayIndex, digit - 1)] |= 0x80;
            }
            continue;
        }

        _buffer[rawIndex(displayIndex, digit)] = encodeChar(text[i]);
        digit++;
    }
}

void TM1640_4x4CC::setDisplay1(const char* text) { setDisplay(0, text); }
void TM1640_4x4CC::setDisplay2(const char* text) { setDisplay(1, text); }
void TM1640_4x4CC::setDisplay3(const char* text) { setDisplay(2, text); }
void TM1640_4x4CC::setDisplay4(const char* text) { setDisplay(3, text); }

void TM1640_4x4CC::setDisplayNumber(uint8_t displayIndex, int value, bool leadingZeros) {
    if (displayIndex > 3) return;

    char out[5] = {' ', ' ', ' ', ' ', '\0'};
    bool negative = (value < 0);

    long safeValue = value;
    if (safeValue < 0) safeValue = -safeValue;
    safeValue %= 10000; // keep it simple: 4 digits max

    for (int8_t i = 3; i >= 0; i--) {
        out[i] = char('0' + (safeValue % 10));
        safeValue /= 10;
    }

    if (!leadingZeros) {
        for (uint8_t i = 0; i < 3; i++) {
            if (out[i] == '0' && out[i + 1] != '\0') {
                out[i] = ' ';
            } else {
                break;
            }
        }
    }

    if (negative) {
        // Put minus sign into the first available left position.
        for (uint8_t i = 0; i < 4; i++) {
            if (out[i] != ' ') {
                if (i == 0) out[0] = '-';
                else out[i - 1] = '-';
                break;
            }
            if (i == 3) out[3] = '-';
        }
    }

    setDisplay(displayIndex, out);
}

void TM1640_4x4CC::setDisplayClock(uint8_t displayIndex, uint8_t hour, uint8_t minute, bool colonOn) {
    if (displayIndex > 3) return;

    hour %= 100;
    minute %= 100;

    setDigit(displayIndex, 0, char('0' + ((hour / 10) % 10)), false);
    setDigit(displayIndex, 1, char('0' + (hour % 10)), colonOn);
    setDigit(displayIndex, 2, char('0' + ((minute / 10) % 10)), false);
    setDigit(displayIndex, 3, char('0' + (minute % 10)), false);
}

void TM1640_4x4CC::start() {
    digitalWrite(_dataPin, HIGH);
    digitalWrite(_clockPin, HIGH);
    digitalWrite(_dataPin, LOW);
}

void TM1640_4x4CC::stop() {
    digitalWrite(_clockPin, LOW);
    digitalWrite(_dataPin, LOW);
    digitalWrite(_clockPin, HIGH);
    digitalWrite(_dataPin, HIGH);
}

void TM1640_4x4CC::writeByte(uint8_t data) {
    for (uint8_t i = 0; i < 8; i++) {
        digitalWrite(_clockPin, LOW);
        digitalWrite(_dataPin, (data & 0x01) ? HIGH : LOW);
        data >>= 1;
        digitalWrite(_clockPin, HIGH);
    }
}

void TM1640_4x4CC::update() {
    // Data command: auto increment mode.
    start();
    writeByte(0x40);
    stop();

    // Address command: start from 0x00.
    start();
    writeByte(0xC0);
    for (uint8_t i = 0; i < 16; i++) {
        writeByte(_buffer[i]);
    }
    stop();

    // Display control command: on/off + brightness.
    start();
    writeByte((_displayOn ? 0x88 : 0x80) | (_brightness & 0x07));
    stop();
}
