#ifndef TM1640_4X4CC_H
#define TM1640_4X4CC_H

#include <Arduino.h>

/*
  TM1640_4x4CC
  -----------------
  Simple Arduino library for a custom TM1640 board with 4 x 4-digit
  common-cathode 7-segment displays (16 digits total).

      [DISPLAY1] [DISPLAY2]
      [DISPLAY3] [DISPLAY4]

  Public display indexes:
      0 = DISPLAY1
      1 = DISPLAY2
      2 = DISPLAY3
      3 = DISPLAY4

  Dot / colon note:
  The board uses the DP of digit 2 together with the physical ':' LEDs.
  For clock view, use setDisplayClock().
  
*/
class TM1640_4x4CC {
public:
    // Create the driver with TM1640 DIN and CLK pins.
    TM1640_4x4CC(uint8_t dataPin, uint8_t clockPin);

    // Initialize GPIO and clear the display buffer.
    void begin();

    // Send the local buffer to TM1640.
    void update();

    // Clear all 16 digits in the local buffer.
    void clear();

    // Clear only one logical display (0..3).
    void clearDisplay(uint8_t displayIndex);

    // Set brightness level: 0 (lowest) .. 7 (highest).
    void setBrightness(uint8_t brightness);

    // Turn display output on or off.
    void setOn(bool state);

    // Write up to 4 characters to one logical display.
    // '.' lights the dot of the previous digit.
    // Example: "12.34" -> [1][2.][3][4]
    void setDisplay(uint8_t displayIndex, const char* text);

    // Convenience wrappers for the 4 physical displays.
    void setDisplay1(const char* text);
    void setDisplay2(const char* text);
    void setDisplay3(const char* text);
    void setDisplay4(const char* text);

    // Print an integer value to one logical display.
    // leadingZeros = true  -> 0042
    // leadingZeros = false ->   42
    void setDisplayNumber(uint8_t displayIndex, int value, bool leadingZeros = false);

    // Show time as HH:MM on one display.
    // colonOn controls the shared DP / ':' line.
    void setDisplayClock(uint8_t displayIndex, uint8_t hour, uint8_t minute, bool colonOn = true);

    // Write one digit to one logical display.
    // digitIndex: 0..3 from left to right.
    // dot: true lights that digit's DP.
    void setDigit(uint8_t displayIndex, uint8_t digitIndex, char value, bool dot = false);

    // Write a raw segment byte to a global digit index (0..15).
    // Bit order: A,B,C,D,E,F,G,DP -> bit0..bit7
    void setDigitRaw(uint8_t globalDigitIndex, uint8_t segments);

private:
    uint8_t _dataPin;
    uint8_t _clockPin;
    uint8_t _buffer[16];
    uint8_t _brightness;
    bool _displayOn;

    // Map logical display index (0..3) to the board's raw scan order.
    uint8_t mapDisplay(uint8_t displayIndex) const;

    // Convert logical display + digit to global raw index 0..15.
    uint8_t rawIndex(uint8_t displayIndex, uint8_t digitIndex) const;

    // Encode supported characters into 7-segment pattern.
    uint8_t encodeChar(char c) const;

    // Low-level TM1640 serial helpers.
    void start();
    void stop();
    void writeByte(uint8_t data);
};

#endif
